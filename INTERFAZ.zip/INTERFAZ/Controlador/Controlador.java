package Controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import Modelo.Algoritmos;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;
import Vista.Interfaz;

public class Controlador implements ActionListener {
    @Override
    public void actionPerformed(ActionEvent e) {
        JFileChooser fileChooser = new JFileChooser();
        int result = fileChooser.showOpenDialog(null);
        if (result == JFileChooser.APPROVE_OPTION) {
            File selectedFile = fileChooser.getSelectedFile();
            ArrayList<Integer> numbers = new ArrayList<>();

            try {
                Scanner scanner = new Scanner(selectedFile);
                while (scanner.hasNextLine()) {
                    int number = Integer.parseInt(scanner.nextLine());
                    numbers.add(number);
                }
                scanner.close();

                Interfaz.numbersArray = new int[numbers.size()];
                for (int i = 0; i < numbers.size(); i++) {
                    Interfaz.numbersArray[i] = numbers.get(i);
                }

            } catch (IOException ex) {
                ex.printStackTrace();
            }
        }

    }

    public void ordenar(String seleccion) {
        
        
            int[] numeros = Interfaz.numbersArray; // Usar el arreglo numbersArray definido en Interfaz

            if (seleccion.equals("ASCENDENTE")) {
                Algoritmos.mergeSort(numeros, 0, numeros.length - 1);
            }else if (seleccion.equals("DESCENDENTE")) {
                Algoritmos.mergeSortDes(numeros, 0, numeros.length - 1);
            }
            Interfaz.numbersArray = numeros;
        
    }
    
    public void guardar() {
        if (Interfaz.numbersArray != null) {
            JFileChooser saveFileChooser = new JFileChooser();
            int saveResult = saveFileChooser.showSaveDialog(null);
            if (saveResult == JFileChooser.APPROVE_OPTION) {
                File saveFile = saveFileChooser.getSelectedFile();

                try {
                    FileWriter writer = new FileWriter(saveFile);

                    for (int number : Interfaz.numbersArray) { // Reemplaza "numerosArrayOrdenados" con el nombre correcto de tu arreglo
                    String numeroComoCadena = String.valueOf(number);
                    writer.write(numeroComoCadena + "\n"); // Agregar un salto de línea después de cada número
                    }

                    writer.close();
                    JOptionPane.showMessageDialog(null, "Numeros ordenados guardados exitosamente en el archivo seleccionado.");
                } catch (IOException ex) {
                    ex.printStackTrace();
                }
            }
        } else {
            JOptionPane.showMessageDialog(null, "No se han ordenado números aún.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
   

}